<?php

namespace BanquemondialeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BanquemondialeBundle extends Bundle
{
}
