<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace BanquemondialeBundle\Controller;

/**
 * Description of DocumentCollectedController
 *
 * @author fgueye
 */
class DocumentCollectedController {
    //put your code here
}
