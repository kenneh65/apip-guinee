<?php

namespace BanquemondialeBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class UpdateTestControllerControllerTest extends WebTestCase
{
}
