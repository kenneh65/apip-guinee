<?php

namespace BanquemondialeBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class HelpDeskControllerTest extends WebTestCase
{
}
