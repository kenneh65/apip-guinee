<?php

namespace DefaultBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DefaultBundle extends Bundle
{
}
